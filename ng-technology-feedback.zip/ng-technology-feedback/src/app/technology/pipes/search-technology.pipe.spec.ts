import { SearchTechnologyPipe } from './search-technology.pipe';

describe('SearchTechnologyPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchTechnologyPipe();
    expect(pipe).toBeTruthy();
  });
});
