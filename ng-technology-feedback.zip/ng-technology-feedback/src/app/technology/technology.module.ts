import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";

import { NgxPaginationModule } from 'ngx-pagination';

import { TechnologyListComponent } from './components/technology-list/technology-list.component';
import { TechnologyDetailsComponent } from './components/technology-details/technology-details.component';
import { SearchTechnologyPipe } from './pipes/search-technology.pipe';

@NgModule({
  declarations: [
    TechnologyListComponent,
    TechnologyDetailsComponent,
    SearchTechnologyPipe
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgxPaginationModule
  ],
  exports:[
    TechnologyListComponent
  ]
})
export class TechnologyModule { }
